const config = {
  apiUrl: 'http://localhost:3522'
};

export default config;