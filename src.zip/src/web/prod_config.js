const config = {
    //test1
    apiUrl: '/api_shoma_otsuka'
  };
  
  export default config;